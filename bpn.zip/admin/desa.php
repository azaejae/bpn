<button class="btn btn-success" id="tambah_desa" style="margin-bottom: 10px;" value="Tambah Desa">Tambah Desa</button>
<table id="desa" class="row-border table table-bordered" cellspacing="0" width="100%">
    <thead>
    <tr>
        <th>ID</th>
        <th>Kode</th>
        <th>Nama Desa</th>
        <th>Nama Kecamatan</th>
    </tr>
    </thead>
    <tbody>


    </tbody>
</table>
