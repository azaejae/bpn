<button class="btn btn-success" id="tambah_kecamatan" style="margin-bottom: 10px;" value="Tambah Kecamatan">Tambah Kecamatan</button>
<table id="kecamatan" class="row-border table table-bordered" cellspacing="0" width="100%" class="table table-bordered">
    <thead>
    <tr>
        <th>ID</th>
        <th>Kode</th>
        <th>Nama Kecamatan</th>
    </tr>
    </thead>
    <tbody>


    </tbody>
</table>
