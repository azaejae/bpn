<form id="f_tambah_kecamatan" method="POST" role="form">
    <div class="form-group">
        <input type="text" name="kode" class="form-control" required placeholder="Kode Kecamatan">
    </div>
    <div class="form-group">
        <input type="text" name="nama_kecamatan" class="form-control" required placeholder="Nama Kecamatan">
    </div>
    <div class="form-group">
        <input type="submit" class="btn btn-primary text-right" value="Tambah Kecamatan">
    </div>
</form>